"""
NAI 작가 태그 자동 업로드 스크립트
====================================

.docx 파일 안 표에서 작가 태그명을 읽어서,
NovelAI API로 girl / boy / 빈프롬(none) 3장씩 이미지를 생성하고,
Supabase Storage에 업로드한 뒤, Firestore(artistTags 컬렉션)에 자동으로 저장합니다.

사용 전 아래 "설정값" 부분을 반드시 채워주세요.
"""

import io
import json
import re
import time
import traceback
import zipfile
from pathlib import Path

import requests
from docx import Document
import firebase_admin
from firebase_admin import credentials, firestore
from supabase import create_client

# ============================================================
# 설정값 — 여기를 본인 환경에 맞게 채워주세요
# ============================================================

# 1) 태그명이 들어있는 .docx 파일 경로
DOCX_PATH = "tags.docx"

# 2) NovelAI API 토큰 (novelai.net → Account → Get Persistent API Token)
NAI_API_TOKEN = "여기에_NAI_토큰_붙여넣기"

# 3) Firebase 서비스 계정 키 (.json) 파일 경로
SERVICE_ACCOUNT_PATH = "serviceAccountKey.json"

# 4) Supabase 프로젝트 URL (Project Settings -> API -> Project URL)
SUPABASE_URL = "https://xxxxx.supabase.co"

# 5) Supabase anon public 키 (Project Settings -> API -> anon public)
SUPABASE_ANON_KEY = "여기에_Supabase_anon_key_붙여넣기"

# 6) Storage에 만든 공개(Public) 버킷 이름 — 웹앱 .env의 VITE_SUPABASE_BUCKET과 동일해야 함
SUPABASE_BUCKET = "nai-images"

# 7) 이미지 생성 옵션 (필요시 조정)
NAI_MODEL = "nai-diffusion-4-5-full"
IMAGE_WIDTH = 832
IMAGE_HEIGHT = 1216
STEPS = 28
SCALE = 5.0  # Prompt Guidance
SAMPLER = "k_euler_ancestral"
NOISE_SCHEDULE = "karras"

# 슬롯별로 태그 뒤에 덧붙일 프롬프트
SLOT_SUFFIXES = {
    "girl": "1girl",
    "boy": "1boy",
    "none": "",  # 빈프롬: 작가 태그만 사용
}

NEGATIVE_PROMPT = (
    "lowres, bad anatomy, bad hands, text, error, missing fingers, "
    "extra digit, fewer digits, cropped, worst quality, low quality, "
    "normal quality, jpeg artifacts, signature, watermark, blurry"
)

# 요청 사이 대기 시간(초) — API 과부하/속도 제한 방지용
REQUEST_DELAY = 2

# 업로드가 순간적으로 실패했을 때, 재시도 전 기다리는 기본 시간(초)
# 실제 대기 시간은 시도 횟수에 비례해 늘어납니다 (예: 5초 -> 10초 -> 15초 ...)
UPLOAD_RETRY_BACKOFF = 5

# ============================================================
# 여기부터는 수정하지 않아도 됩니다
# ============================================================


def read_tags_from_docx(path):
    """표에서 이미지가 아닌 텍스트 셀(작가 태그명)만 추출합니다."""
    doc = Document(path)
    tags = []

    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                text = cell.text.strip()
                # 빈 셀(이미지만 있는 셀)은 text가 비어있으므로 자동으로 걸러짐
                if text and text not in tags:
                    tags.append(text)

    return tags


def generate_image(prompt, negative_prompt):
    """NAI API로 이미지 1장을 생성하고 PNG bytes를 반환합니다."""
    url = "https://image.novelai.net/ai/generate-image"
    headers = {
        "Authorization": f"Bearer {NAI_API_TOKEN}",
        "Content-Type": "application/json",
    }
    payload = {
        "input": prompt,
        "model": NAI_MODEL,
        "action": "generate",
        "parameters": {
            "width": IMAGE_WIDTH,
            "height": IMAGE_HEIGHT,
            "scale": SCALE,
            "sampler": SAMPLER,
            "steps": STEPS,
            "n_samples": 1,
            "seed": 0,
            "uc": negative_prompt,
            "negative_prompt": negative_prompt,
            "noise_schedule": NOISE_SCHEDULE,
            "quality_toggle": True,
            "qualityToggle": True,
            "params_version": 3,
            "sm": False,
            "sm_dyn": False,
            "cfg_rescale": 0,
            "legacy": False,
            "legacy_v3_extend": False,
            # v4/v4.5 모델은 아래 중첩 구조가 반드시 필요합니다 (없으면 500 에러)
            "v4_prompt": {
                "caption": {
                    "base_caption": prompt,
                    "char_captions": [],
                },
                "use_coords": False,
                "use_order": True,
            },
            "v4_negative_prompt": {
                "caption": {
                    "base_caption": negative_prompt,
                    "char_captions": [],
                },
                "legacy_uc": False,
            },
        },
    }

    resp = requests.post(url, headers=headers, json=payload, timeout=120)

    if resp.status_code != 200:
        # NAI가 돌려주는 실제 에러 메시지를 그대로 보여줘서 원인 파악이 쉽도록 함
        try:
            detail = resp.json()
        except Exception:
            detail = resp.text[:500]
        raise RuntimeError(f"NAI API 에러 {resp.status_code}: {detail}")

    # 응답은 zip 파일(바이너리) 형태로 옴 — 안에 image_0.png 가 들어있음
    with zipfile.ZipFile(io.BytesIO(resp.content)) as zf:
        name = zf.namelist()[0]
        return zf.read(name)


def upload_to_supabase(supabase, image_bytes, max_retries=3):
    """PNG bytes를 Supabase Storage에 업로드하고 공개 URL을 반환합니다.

    네트워크 문제 등으로 순간적으로 실패하는 경우, 잠깐 기다렸다가 자동으로 재시도합니다.
    """
    rand_suffix = f"{int(time.time() * 1000)}-{id(image_bytes) % 100000}"
    filename = f"uploads/batch-{rand_suffix}.png"

    last_error = None
    for attempt in range(1, max_retries + 1):
        try:
            supabase.storage.from_(SUPABASE_BUCKET).upload(
                filename,
                image_bytes,
                {"content-type": "image/png", "cache-control": "31536000"},
            )
            return supabase.storage.from_(SUPABASE_BUCKET).get_public_url(filename)
        except Exception as e:
            last_error = e
            if attempt < max_retries:
                wait = UPLOAD_RETRY_BACKOFF * attempt
                print(f"      (Supabase 업로드 실패, {wait}초 대기 후 재시도 {attempt}/{max_retries})")
                time.sleep(wait)

    raise RuntimeError(f"Supabase 업로드 에러: {last_error}")


def main():
    print(f"[1/4] '{DOCX_PATH}'에서 태그 읽는 중...")
    tags = read_tags_from_docx(DOCX_PATH)
    print(f"      -> {len(tags)}개 태그 발견")
    for t in tags:
        print(f"      - {t}")

    if not tags:
        print("태그를 찾지 못했습니다. .docx 파일의 표 구조를 확인해주세요.")
        return

    print("\n[2/4] Firebase 연결 중...")
    if not Path(SERVICE_ACCOUNT_PATH).exists():
        print(f"      ! 서비스 계정 키 파일을 찾을 수 없습니다: {SERVICE_ACCOUNT_PATH}")
        print("      -> upload_tags.py 상단의 SERVICE_ACCOUNT_PATH 값을 확인해주세요.")
        return

    with open(SERVICE_ACCOUNT_PATH, "r", encoding="utf-8") as f:
        sa_data = json.load(f)
    project_id = sa_data.get("project_id")
    if not project_id:
        print("      ! 서비스 계정 키 파일에 project_id가 없습니다. 파일이 손상되었을 수 있어요.")
        return

    cred = credentials.Certificate(SERVICE_ACCOUNT_PATH)
    firebase_admin.initialize_app(cred, {"projectId": project_id})
    db = firestore.client()
    print(f"      -> 연결 완료 (project: {project_id})")

    print("\nSupabase 연결 중...")
    supabase = create_client(SUPABASE_URL, SUPABASE_ANON_KEY)
    print("      -> 연결 완료")

    print("\n[3/4] 이미지 생성 및 업로드 시작 (태그당 3장, 시간이 걸릴 수 있어요)\n")

    for i, tag in enumerate(tags, start=1):
        if not tag or not tag.strip():
            print(f"({i}/{len(tags)}) 빈 태그명이라 건너뜁니다.")
            continue
        print(f"({i}/{len(tags)}) '{tag}' 처리 중...")
        slots = {}
        success = True

        for slot_key, suffix in SLOT_SUFFIXES.items():
            prompt = f"{tag}, {suffix}" if suffix else tag
            try:
                print(f"    - {slot_key} 이미지 생성 중...")
                image_bytes = generate_image(prompt, NEGATIVE_PROMPT)
                time.sleep(REQUEST_DELAY)

                print(f"    - {slot_key} 이미지 업로드 중...")
                time.sleep(REQUEST_DELAY)
                url = upload_to_supabase(supabase, image_bytes)

                slots[slot_key] = {"url": url, "label": slot_key}
            except Exception as e:
                print(f"    ! {slot_key} 처리 실패: {e}")
                slots[slot_key] = {"url": "", "label": slot_key}
                success = False

        try:
            db.collection("artistTags").add(
                {
                    "name": tag,
                    "styles": [],
                    "favorite": False,
                    "slots": slots,
                    "memo": "",
                    "sortOrder": int(time.time() * 1000),
                    "createdAt": firestore.SERVER_TIMESTAMP,
                    "updatedAt": firestore.SERVER_TIMESTAMP,
                }
            )
            status = "완료" if success else "완료 (일부 이미지 누락)"
            print(f"    -> Firestore 저장 {status}\n")
        except Exception as e:
            print(f"    ! Firestore 저장 실패: {e}\n")
            traceback.print_exc()

    print("[4/4] 전체 작업 완료!")


if __name__ == "__main__":
    main()
