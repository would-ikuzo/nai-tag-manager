# NAI 작가 태그 서가

NovelAI 작가 태그를 검색·분류·복사할 수 있는 **1인용** 웹앱입니다. Google 로그인(본인
계정만 허용) + Firebase Firestore로 멀티 디바이스 동기화를 지원합니다.

이 저장소는 **포크해서 각자 본인의 Firebase/Cloudinary 계정에 연결해 쓰는 것**을 전제로
만들어졌습니다. 별도의 회원가입 시스템이 없고, 딱 한 사람(또는 본인이 지정한 소수의
이메일)만 로그인해서 쓸 수 있는 개인용 도구예요.

> ⚠️ 라이선스 안내: 이 프로젝트는 개인적으로 자유롭게 쓰고 수정·재배포할 수 있지만,
> **상업적 이용**이나 **여러 명이 가입해서 쓰는 멀티유저 서비스로 공개 운영**하려면
> 원저작자의 사전 허락이 필요합니다. 자세한 내용은 [LICENSE.md](./LICENSE.md)를
> 확인해주세요.

---

## 지금 어떤 상황이신가요?

- 🆕 **처음 설치하시는 분** → [신규 사용자용 설치 가이드](#신규-사용자용-설치-가이드)로 이동하세요.
- 🔄 **v1.0.0을 이미 쓰고 계신 분** → [기존 사용자용 업데이트 가이드](#기존-사용자용-업데이트-가이드-v100--v110)로 이동하세요.
  (Supabase → Cloudinary 전환이 포함되어 있어 몇 가지 챙길 게 있습니다.)

---

## 1. 이 프로젝트가 하는 일

- 작가 태그를 등록/검색/즐겨찾기/원클릭 복사
- 화풍 등 자유 분류 태그로 다중 필터링 (클릭할 때마다 **미선택 → 포함 → 제외** 순환)
- 즐겨찾기 필터도 **전체 → 즐겨찾기만 → 즐겨찾기 제외** 3단계로 순환 전환
- 태그마다 `girl` / `boy` / `빈프롬(None)` 3개의 예시 이미지 슬롯 (스와이프 전환)
- 정렬: 최신순 / 오래된순 / 알파벳순 / 직접 드래그 정렬
- 작가 태그 조합("그깍") 별도 관리 — 프롬프트, Steps, Prompt Guidance, Sampler 등 저장
- Google 로그인 기반 접근 제한 (지정한 이메일만 접근 가능)
- Firestore 실시간 동기화로 여러 기기에서 같은 데이터 공유

---

## 2. v1.1.0에서 달라진 점

- **이미지 업로드 저장소를 Supabase → Cloudinary로 변경**했습니다. 카드 등록 없이
  Google/GitHub 계정만으로 무료 가입할 수 있어 진입장벽이 낮아졌습니다.
- **화풍/분류 태그 필터가 포함/제외 3단계 순환 방식**으로 바뀌었습니다. 칩을 클릭할
  때마다 미선택 → 포함(파란색) → 제외(빗금) → 다시 미선택 순으로 바뀌며, 포함 조건은
  AND로, 제외 조건은 OR로 동시에 적용됩니다.
- **즐겨찾기 필터도 3단계 순환**으로 바뀌었습니다. 전체 → 즐겨찾기만 → 즐겨찾기 제외
  순으로 전환됩니다.

기존에 등록해둔 태그·이미지 URL·화풍 태그 데이터는 Firestore에 그대로 저장되어 있으므로
별도의 데이터 마이그레이션은 필요 없습니다. 위 변경사항은 모두 프론트엔드 동작 변경입니다.

---

## 3. 준비물

- Node.js 18 이상
- Firebase 프로젝트 (무료 Spark 플랜으로 충분)
- (선택) Cloudinary 계정 — 이미지 드래그앤드롭 업로드 기능을 쓰고 싶다면 필요합니다.
  설정하지 않아도 이미지 URL 직접 입력으로는 계속 사용 가능합니다.

---

## 신규 사용자용 설치 가이드

처음 설치하시는 분은 아래 순서를 그대로 따라오시면 됩니다.

### 4-1. Firebase 콘솔 설정

**프로젝트 생성 & 웹 앱 등록**
1. [Firebase 콘솔](https://console.firebase.google.com/)에서 새 프로젝트 생성
2. 프로젝트 설정 → 내 앱 → `</>` (웹 앱 추가) → 앱 등록
3. 표시되는 `firebaseConfig` 값들을 복사해둡니다 (`apiKey`, `authDomain`, `projectId` 등)

**Authentication 활성화 (Google 로그인)**
1. **Authentication** → **시작하기** → **Sign-in method** 탭
2. **Google** 선택 → 사용 설정 ON → 저장

**Firestore 데이터베이스 생성**
1. **Firestore Database** → **데이터베이스 만들기**
2. 리전은 가까운 곳으로 선택 (한국이면 `asia-northeast3` 추천)
3. 테스트 모드로 시작해도 되지만, 아래 4-3 항목의 보안 규칙을 반드시 적용하세요.

### 4-2. (선택) Cloudinary 설정 — 이미지 업로드 기능

1. [cloudinary.com](https://cloudinary.com)에서 무료 가입 (카드 등록 불필요, Google/GitHub
   계정으로도 가입 가능)
2. 대시보드 상단에서 **Cloud name** 확인
3. **Settings**(톱니바퀴) → **Upload** 탭 → **Upload presets** → **Add upload preset**
4. **Signing Mode**를 반드시 **Unsigned**로 설정 (브라우저에서 직접 업로드하기 위해 필요) → 저장
5. 생성된 preset 이름을 복사

이 단계를 건너뛰어도 앱은 정상 동작하며, 이미지는 URL을 직접 입력해서 쓰면 됩니다.

> ⚠️ Cloudinary의 **API Secret**은 절대 `.env`나 프론트엔드 코드에 넣지 마세요. 이 앱은
> Unsigned Upload Preset만 사용하므로 API Secret 자체가 필요 없습니다.

### 4-3. 프로젝트 설정
아래 명령어를 차례로 터미널에서 실행해주세요.

**패키지 설치**
```bash
npm install
```

**환경변수 설정**
```bash
cp .env.example .env
```
이후 폴더를 확인하면 `.env`라는 파일이 새로 생깁니다. `.env` 파일을 열어 Firebase/Cloudinary
콘솔에서 복사한 값을 채워주세요.

```env
VITE_FIREBASE_API_KEY=AIza...
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project
VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
VITE_FIREBASE_APP_ID=1:123456789:web:abcdef

# 본인 구글 계정 이메일 (이 이메일로만 로그인 허용)
VITE_ALLOWED_EMAILS=you@gmail.com

# (선택) Cloudinary — 안 쓸 거면 비워둬도 됩니다
VITE_CLOUDINARY_CLOUD_NAME=
VITE_CLOUDINARY_UPLOAD_PRESET=
```

> `VITE_ALLOWED_EMAILS`는 클라이언트 단(화면)에서의 1차 방어입니다. 진짜 보안은
> Firestore 보안 규칙(다음 항목)이 담당하므로, **두 곳 모두 같은 이메일로 맞춰주세요.**

**Firestore 보안 규칙에 본인 이메일 반영**

`firestore.rules` 파일을 열어 `YOUR_EMAIL@gmail.com` 부분을 전부 본인 이메일로
바꿔주세요.

```js
allow read, write: if request.auth != null
  && request.auth.token.email == "you@gmail.com";
```

여러 계정을 허용하려면:
```js
allow read, write: if request.auth != null
  && request.auth.token.email in ["you@gmail.com", "second@gmail.com"];
```

### 4-4. 로컬 실행

```bash
npm run dev
```

터미널에 뜨는 주소(기본 `http://localhost:5173`)로 접속하면 로그인 화면이 나옵니다.

### 4-5. Firebase Hosting에 배포하기

로컬에서 제대로 작동하는 것을 확인했다면 실제 사이트에 배포할 수 있습니다. 터미널에서
아래 내용을 순서대로 입력해 주세요. 새 터미널을 열지 않는 것을 추천하며, 새로 열었을 때
자칫 오류가 발생할 수 있습니다.

**Firebase CLI 설치 & 로그인 (최초 1회)**
```bash
npm install -g firebase-tools
firebase login
```

**프로젝트 연결 (최초 1회)**
```bash
firebase use --add
```
목록에서 본인 프로젝트 선택 → 별칭은 `default` 정도로 입력

**Firestore 보안 규칙 배포**
```bash
firebase deploy --only firestore:rules
```

**빌드 후 호스팅 배포**
```bash
npm run build
firebase deploy --only hosting
```

배포가 끝나면 `https://your-project.web.app` 형태의 주소가 출력됩니다.

> 기본 배포 주소 대신 본인만의 이름을 쓰고 싶다면 `firebase hosting:sites:create 원하는이름`
> 으로 사이트를 추가로 만든 뒤, `firebase.json`의 `"hosting"` 안에
> `"site": "원하는이름"` 을 추가하고 다시 배포하면 됩니다.

> Google 로그인이 배포 도메인에서 동작하려면, **Authentication → Settings →
> 승인된 도메인**에 배포된 주소(`your-project.web.app` 등)가 등록되어 있어야 합니다.
> 보통 자동으로 추가되지만, 사이트 이름을 바꿨다면 직접 추가해야 할 수 있습니다.

설치 중 막히는 부분이 있다면 [SETUP_CHECKLIST.md](./SETUP_CHECKLIST.md)에서 자주 걸리는
지점만 빠르게 체크해볼 수 있습니다.

---

## 기존 사용자용 업데이트 가이드 (v1.0.0 → v1.1.0)

이미 v1.0.0을 설치해서 쓰고 계신 분들을 위한 업데이트 절차입니다. **Firebase
프로젝트나 Firestore 데이터를 새로 만들 필요는 없습니다.** 데이터는 그대로 Firestore에
남아있고, 이번 업데이트는 프론트엔드 코드 변경(+ 이미지 업로드 저장소 전환)입니다.

### 5-1. 시작 전 백업

기존 폴더에서 `.env`, `firebase.json`, `firestore.rules` 파일들은 따로 복사해두는 것을 추천합니다.

### 5-2. 새 버전 압축 해제

이 zip(`nai-tag-manager-opensource-v1.1.0`)을 원하는 위치에 풀어주세요. 기존 폴더를
덮어쓰지 말고 **새 폴더로 압축을 풀어서** 아래 항목들을 옮겨오는 방식을 권장합니다.

### 5-3. 기존 설정 파일 옮기기

새 폴더에 아래 파일들을 기존 폴더 기준으로 다시 채워주세요.

- **`firestore.rules`**: 기존 파일과 동일한 파일로 붙여넣어 주세요. (파일 변경사항 없음)
- **`firebase.json`**: 만약 기존에 `firebase hosting:sites:create`로 커스텀 사이트
  이름을 만들어서 `"hosting"` 안에 `"site": "원하는이름"`을 추가해두셨다면, 새
  `firebase.json`에도 동일하게 추가해주세요. (배포용 개인 설정이라 배포판에는 빠져있습니다.)
- **`.env`**: 기존 `.env` 파일을 새 폴더로 그대로 복사해주세요. 단, 아래 5-4 항목처럼
  Cloudinary 관련 값을 **새로 추가**해야 합니다.

### 5-4. Supabase → Cloudinary 전환

v1.1.0부터 이미지 드래그앤드롭 업로드가 Supabase 대신 **Cloudinary**를 사용합니다. Supabase의 경우 무료 한도가 빡빡하며, 이 점을 확인하지 못하고 배포하였습니다.

1. [cloudinary.com](https://cloudinary.com)에서 무료 가입 (카드 등록 불필요)
2. 대시보드 상단에서 **Cloud name** 확인
3. **Settings** → **Upload** 탭 → **Upload presets** → **Add upload preset** →
   **Signing Mode**를 **Unsigned**로 설정 → 저장 → preset 이름 복사
4. `.env`에 아래 두 줄을 추가하고, 기존 `VITE_SUPABASE_*` 줄은 지워도 됩니다
   (더 이상 코드에서 읽지 않습니다):

```env
VITE_CLOUDINARY_CLOUD_NAME=
VITE_CLOUDINARY_UPLOAD_PRESET=
```

> 기존에 Supabase Storage에 올려두신 이미지는 그대로 잘 보입니다. Firestore에는 이미지
> **URL 문자열만** 저장되기 때문에, 예전 Supabase 프로젝트를 삭제하지 않는 한 계속
> 정상적으로 표시됩니다. **새로 업로드하는 이미지부터** Cloudinary로 저장됩니다. 이미지 이동을 원하는 경우에는 nai-batch-tool을 이용해 주세요.
> (Cloudinary 설정을 아예 건너뛰어도 URL 직접 입력으로는 계속 쓸 수 있습니다.)

### 5-5. 패키지 재설치 & 실행 확인

```bash
npm install
npm run dev
```

로그인 후 기존에 등록해둔 태그들이 그대로 보이는지, 화풍 필터 칩을 클릭했을 때 포함/제외가
순환되는지, 즐겨찾기 필터가 3단계로 전환되는지 확인해보세요.

### 5-6. 재배포

```bash
npm run build
firebase deploy --only hosting
```

Firestore 보안 규칙은 이번 버전에서 바뀌지 않았으므로 `firestore:rules`를 다시 배포할
필요는 없습니다 (다만 기존에 배포해둔 규칙이 없다면 신규 설치 가이드의 4-5 항목을
참고해 배포해주세요).

---

## 6. 기능 요약

| 기능 | 설명 |
|---|---|
| Google 로그인 | 지정한 이메일만 접근 허용 (클라이언트 화이트리스트 + Firestore 규칙 이중 체크) |
| 실시간 동기화 | Firestore `onSnapshot`으로 여러 기기 간 즉시 반영 |
| 검색 | 태그명 실시간 검색 |
| 즐겨찾기 | ★ 토글, 전체/즐겨찾기만/즐겨찾기 제외 3단계 필터 |
| 원클릭 복사 | 태그 카드의 복사 아이콘 클릭 시 클립보드 복사 |
| 정렬 | 최신순 / 오래된순 / 알파벳순 / 기타(드래그로 직접 순서 변경, Firestore에 저장됨) |
| 화풍/분류 태그 | 작가 태그당 다중 분류 태그 부여, 칩 클릭으로 미선택→포함→제외 순환, 포함은 AND·제외는 OR로 동시 적용 |
| 화풍 태그 관리 | 화풍/분류 태그를 별도 화면에서 등록·이름변경·삭제 (`styleTags` 컬렉션으로 독립 관리) |
| 일괄 작업 | 카드 다중 선택 후 화풍 태그 일괄 추가, 즐겨찾기 일괄 등록/해제, 일괄 삭제 |
| 예시 이미지 3슬롯 | `girl` / `boy` / `빈프롬(None)` 슬롯별 이미지, 스와이프/좌우 화살표로 전환 |
| 전역 슬롯 필터 | 상단 `전체/girl/boy/빈프롬` 토글 선택 시 모든 카드가 해당 슬롯 이미지로 고정 표시 |
| 이미지 업로드 | Cloudinary 설정 시 드래그앤드롭/클릭으로 이미지 파일 업로드 가능. 미설정 시 URL 직접 입력만 가능 |
| 그깍(조합) 탭 | 작가 태그 조합 관리 — 메인/부정 프롬프트, Steps·Prompt Guidance·Sampler 설정, Advanced(Rescale·Noise Schedule), 화풍/예시 이미지/즐겨찾기까지 작가 태그와 동일하게 지원 |

---

## 7. 폴더 구조

```
src/
  components/     화면 구성 요소 (카드, 모달, 필터바, 캐러셀, 일괄작업바 등)
  hooks/          useAuth(로그인), useCollection(공통 CRUD), useStyleTags(화풍 태그 관리)
  lib/            firebase.js, uploadImage.js (Cloudinary 업로드)
  styles/         디자인 토큰 + 전체 스타일시트
firestore.rules    Firestore 보안 규칙 (본인 이메일로 수정 필요)
firebase.json      Hosting/Firestore 배포 설정
LICENSE.md         라이선스 (사용 조건)
```

---

## 8. 자주 발생할 수 있는 문제

- **로그인 버튼이 비활성화되어 있어요** → `.env`의 Firebase 설정값이 비어있는지 확인하세요.
- **로그인은 되는데 "접근이 허용되지 않았습니다" 메시지가 떠요** → `.env`의
  `VITE_ALLOWED_EMAILS`와 로그인한 구글 계정 이메일이 일치하는지 확인하세요.
- **저장 버튼을 눌러도 반응이 없어요 (Firestore 권한 에러)** → `firestore.rules`에
  본인 이메일을 반영했는지, 그리고 그 규칙을 실제로 **게시(Publish)** 했는지
  (Firebase 콘솔 또는 `firebase deploy --only firestore:rules`) 확인하세요.
- **이미지가 안 떠요** → 입력한 이미지 URL이 실제로 브라우저에서 직접 열리는 이미지
  주소인지 확인하세요. (리다이렉트되는 공유 링크는 안 될 수 있습니다.)
- **업데이트 후 이미지 업로드가 안 돼요** → v1.1.0부터는 Cloudinary를 사용합니다. `.env`에
  `VITE_CLOUDINARY_CLOUD_NAME` / `VITE_CLOUDINARY_UPLOAD_PRESET`이 설정되어 있는지
  확인하세요. (기존 `VITE_SUPABASE_*` 값은 더 이상 사용되지 않습니다.)
- **로그인 시 `auth/unauthorized-domain` 에러** → Firebase Authentication → Settings →
  승인된 도메인에 배포 주소를 추가하세요.

---

## 9. 기여 / 문의

버그 제보나 개선 제안, 이해되지 않는 점은 `would.ikuzo@gmail.com`으로 남겨주세요. 상업적 이용이나 멀티유저
서비스 운영을 원하시면 위 이메일을 통해 먼저 연락해주세요.

사소한 버그 및 기능이나 막힌 부분은 AI를 활용해도 좋습니다. 프로젝트 파일을 업로드하고 상황을 설명해보세요.

문의 답변 시간은 일정하지 않으며, 답변이 오기까지 오래 걸릴 수 있습니다.
버그 수정의 경우 일반적으로 주말에만 진행되기 때문에, 급한 경우 AI를 통해 직접 수정하는 것을 권장합니다.
