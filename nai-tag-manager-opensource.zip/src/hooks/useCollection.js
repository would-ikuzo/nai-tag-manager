import { useEffect, useState, useCallback, useRef } from 'react'
import {
  collection,
  onSnapshot,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  serverTimestamp,
  query,
  orderBy,
  writeBatch,
} from 'firebase/firestore'
import { db } from '../lib/firebase'

export const emptySlots = () => ({
  girl: { url: '', label: 'girl' },
  boy: { url: '', label: 'boy' },
  none: { url: '', label: '빈프롬' },
})

/**
 * Firestore 컬렉션 하나에 대한 realtime CRUD 훅.
 * 작가 태그(artistTags)와 그깍 조합(combos) 모두 이 훅을 재사용합니다.
 *
 * `sortOrder` 필드는 "직접 정렬(기타)" 모드에서 드래그로 바꾼 순서를 저장하는 용도입니다.
 */
export function useCollection(user, collectionName, buildDefaults) {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const savingRef = useRef(false)

  useEffect(() => {
    if (!user || !db) {
      setItems([])
      setLoading(false)
      return
    }
    setLoading(true)
    const q = query(collection(db, collectionName), orderBy('createdAt', 'desc'))
    const unsub = onSnapshot(
      q,
      (snapshot) => {
        const rows = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }))
        setItems(rows)
        setLoading(false)
      },
      (err) => {
        console.error(err)
        setError(err.message)
        setLoading(false)
      }
    )
    return () => unsub()
  }, [user, collectionName])

  const addItem = useCallback(
    async (data) => {
      // 중복 클릭으로 인한 이중 저장을 막기 위한 간단한 잠금
      if (savingRef.current) return
      savingRef.current = true
      try {
        await addDoc(collection(db, collectionName), {
          ...buildDefaults(data),
          favorite: false,
          sortOrder: Date.now(),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        })
      } finally {
        savingRef.current = false
      }
    },
    [collectionName, buildDefaults]
  )

  const updateItem = useCallback(
    async (id, data) => {
      await updateDoc(doc(db, collectionName, id), {
        ...data,
        updatedAt: serverTimestamp(),
      })
    },
    [collectionName]
  )

  const deleteItem = useCallback(
    async (id) => {
      await deleteDoc(doc(db, collectionName, id))
    },
    [collectionName]
  )

  const toggleFavorite = useCallback(
    async (id, favorite) => {
      await updateItem(id, { favorite: !favorite })
    },
    [updateItem]
  )

  // 드래그로 바뀐 순서를 한 번에 저장 (배치 write)
  const persistOrder = useCallback(
    async (orderedIds) => {
      const batch = writeBatch(db)
      orderedIds.forEach((id, index) => {
        batch.update(doc(db, collectionName, id), { sortOrder: index })
      })
      await batch.commit()
    },
    [collectionName]
  )

  // 선택한 여러 항목을 한 번에 삭제
  const batchDelete = useCallback(
    async (ids) => {
      const batch = writeBatch(db)
      ids.forEach((id) => batch.delete(doc(db, collectionName, id)))
      await batch.commit()
    },
    [collectionName]
  )

  // 선택한 여러 항목의 즐겨찾기 상태를 한 번에 설정
  const batchSetFavorite = useCallback(
    async (ids, favorite) => {
      const batch = writeBatch(db)
      ids.forEach((id) => batch.update(doc(db, collectionName, id), { favorite }))
      await batch.commit()
    },
    [collectionName]
  )

  // 선택한 여러 항목에 화풍/분류 태그를 한 번에 추가 (이미 있는 항목은 건너뜀)
  const batchAddStyle = useCallback(
    async (ids, styleName) => {
      const batch = writeBatch(db)
      ids.forEach((id) => {
        const target = items.find((it) => it.id === id)
        if (!target) return
        const current = target.styles || []
        if (current.includes(styleName)) return
        batch.update(doc(db, collectionName, id), { styles: [...current, styleName] })
      })
      await batch.commit()
    },
    [collectionName, items]
  )

  return {
    items,
    loading,
    error,
    addItem,
    updateItem,
    deleteItem,
    toggleFavorite,
    persistOrder,
    batchDelete,
    batchSetFavorite,
    batchAddStyle,
  }
}
