import { useState } from 'react'
import SlotCarousel from './SlotCarousel'

function displayComboName(combo) {
  if (combo.name?.trim()) return combo.name
  if (combo.mainPrompt?.trim()) {
    const trimmed = combo.mainPrompt.trim()
    return trimmed.slice(0, 24) + (trimmed.length > 24 ? '…' : '')
  }
  return '(이름 없음)'
}

export default function ComboCard({ combo, globalFilter, onToggleFavorite, onEdit, onDelete }) {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(combo.mainPrompt || '')
      setCopied(true)
      setTimeout(() => setCopied(false), 1200)
    } catch {
      // clipboard unavailable — ignore
    }
  }

  const s = combo.settings || {}

  return (
    <article className="tag-card">
      <SlotCarousel slots={combo.slots} globalFilter={globalFilter} editable={false} />

      <div className="tag-card-body">
        <div className="tag-name-row">
          <span className={`tag-name ${!combo.name?.trim() ? 'tag-name--fallback' : ''}`} title={displayComboName(combo)}>
            {displayComboName(combo)}
          </span>
          <button
            className={`copy-btn ${copied ? 'is-copied' : ''}`}
            onClick={handleCopy}
            aria-label="메인 프롬프트 복사"
            type="button"
          >
            {copied ? (
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            ) : (
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                <rect x="9" y="9" width="12" height="12" rx="2" stroke="currentColor" strokeWidth="1.8" />
                <path d="M5 15V5a2 2 0 0 1 2-2h10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
            )}
          </button>
        </div>

        {combo.mainPrompt && <p className="combo-prompt-preview">{combo.mainPrompt}</p>}

        <div className="combo-settings-summary">
          <span className="setting-pill">Steps {s.steps}</span>
          <span className="setting-pill">CFG {s.promptGuidance}</span>
          <span className="setting-pill">{s.sampler}</span>
        </div>

        {combo.styles?.length > 0 && (
          <div className="tag-style-chips">
            {combo.styles.map((st) => (
              <span key={st} className="style-chip">
                {st}
              </span>
            ))}
          </div>
        )}

        <div className="tag-actions">
          <button
            className={`fav-btn ${combo.favorite ? 'is-fav' : ''}`}
            onClick={() => onToggleFavorite(combo.id, combo.favorite)}
            aria-label={combo.favorite ? '즐겨찾기 해제' : '즐겨찾기 추가'}
            type="button"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill={combo.favorite ? 'currentColor' : 'none'}>
              <path
                d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinejoin="round"
              />
            </svg>
          </button>
          <button className="edit-btn" onClick={() => onEdit(combo)} type="button">
            수정
          </button>
          <button className="delete-btn" onClick={() => onDelete(combo)} type="button">
            삭제
          </button>
        </div>
      </div>
    </article>
  )
}
