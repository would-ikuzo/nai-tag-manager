import { useState, useRef, useEffect } from 'react'
import { uploadImage, storageConfigured } from '../lib/uploadImage'
import LazyImage from './LazyImage'

const SLOT_ORDER = ['girl', 'boy', 'none']
const SLOT_META = {
  girl: { label: 'girl', className: 'tab-girl' },
  boy: { label: 'boy', className: 'tab-boy' },
  none: { label: '빈프롬', className: 'tab-none' },
}

export default function SlotCarousel({ slots, globalFilter, editable, onSlotUrlChange }) {
  const order = globalFilter && globalFilter !== 'all' ? [globalFilter] : SLOT_ORDER
  const [index, setIndex] = useState(0)
  const [isDragging, setIsDragging] = useState(false)
  const [uploadState, setUploadState] = useState(null) // null | 'loading' | 'error'
  const [uploadError, setUploadError] = useState('')
  const touchStartX = useRef(null)
  const fileInputRef = useRef(null)
  const dragCounter = useRef(0)

  useEffect(() => {
    setIndex(0)
  }, [globalFilter])

  const activeKey = order[index] || order[0]
  const activeSlot = slots?.[activeKey] || { url: '', label: SLOT_META[activeKey].label }
  const locked = globalFilter && globalFilter !== 'all'

  const goTo = (i) => {
    if (locked) return
    setIndex((i + order.length) % order.length)
  }

  const handleTouchStart = (e) => {
    touchStartX.current = e.touches[0].clientX
  }
  const handleTouchEnd = (e) => {
    if (touchStartX.current === null) return
    const delta = e.changedTouches[0].clientX - touchStartX.current
    if (Math.abs(delta) > 40) {
      if (delta > 0) goTo(index - 1)
      else goTo(index + 1)
    }
    touchStartX.current = null
  }

  const handleFile = async (file) => {
    if (!file || !editable) return
    setUploadState('loading')
    setUploadError('')
    const result = await uploadImage(file)
    if (result.success) {
      onSlotUrlChange(activeKey, result.url)
      setUploadState(null)
    } else {
      setUploadState('error')
      setUploadError(result.reason)
    }
  }

  const handleDragEnter = (e) => {
    if (!editable) return
    e.preventDefault()
    dragCounter.current += 1
    setIsDragging(true)
  }
  const handleDragLeave = (e) => {
    if (!editable) return
    e.preventDefault()
    dragCounter.current -= 1
    if (dragCounter.current <= 0) {
      setIsDragging(false)
      dragCounter.current = 0
    }
  }
  const handleDragOver = (e) => {
    if (!editable) return
    e.preventDefault()
  }
  const handleDrop = (e) => {
    if (!editable) return
    e.preventDefault()
    setIsDragging(false)
    dragCounter.current = 0
    const file = e.dataTransfer.files?.[0]
    handleFile(file)
  }

  return (
    <div className="slot-carousel">
      <div
        className={`slot-viewport ${isDragging ? 'is-dragging' : ''} ${
          editable ? 'is-editable' : ''
        }`}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onClick={() => editable && uploadState !== 'loading' && fileInputRef.current?.click()}
        role={editable ? 'button' : undefined}
        tabIndex={editable ? 0 : undefined}
      >
        {activeSlot.url ? (
          <LazyImage
            src={activeSlot.url}
            alt={`${activeKey} 예시 이미지`}
            className="slot-lazy-image"
          />
        ) : (
          <div className="slot-empty">
            {editable
              ? uploadState === 'loading'
                ? '업로드 중...'
                : '클릭 또는 이미지를 끌어다 놓으세요'
              : '이미지 없음'}
          </div>
        )}

        {editable && uploadState === 'loading' && (
          <div className="slot-upload-overlay">업로드 중...</div>
        )}

        {editable && isDragging && <div className="slot-drop-overlay">여기에 놓기</div>}

        <span className={`slot-tag ${SLOT_META[activeKey].className}`}>
          {SLOT_META[activeKey].label}
        </span>

        {!locked && order.length > 1 && (
          <>
            <button
              className="slot-nav slot-nav--prev"
              onClick={(e) => {
                e.stopPropagation()
                goTo(index - 1)
              }}
              aria-label="이전 이미지"
              type="button"
            >
              ‹
            </button>
            <button
              className="slot-nav slot-nav--next"
              onClick={(e) => {
                e.stopPropagation()
                goTo(index + 1)
              }}
              aria-label="다음 이미지"
              type="button"
            >
              ›
            </button>
          </>
        )}
      </div>

      {editable && (
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          hidden
          onChange={(e) => handleFile(e.target.files?.[0])}
        />
      )}

      {!locked && order.length > 1 && (
        <div className="slot-dots">
          {order.map((key, i) => (
            <button
              key={key}
              className={`slot-dot ${i === index ? 'is-active' : ''}`}
              onClick={() => goTo(i)}
              aria-label={`${SLOT_META[key].label} 보기`}
              type="button"
            />
          ))}
        </div>
      )}

      {editable && (
        <>
          {!storageConfigured && (
            <p className="slot-upload-hint">
              이미지 업로드를 쓰려면 .env에 VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY를
              설정해주세요. 지금은 URL만 입력할 수 있어요.
            </p>
          )}
          {uploadState === 'error' && <p className="slot-upload-error">{uploadError}</p>}
          <input
            className="slot-url-input"
            type="url"
            placeholder={`${SLOT_META[activeKey].label} 이미지 URL (직접 입력도 가능)`}
            value={activeSlot.url}
            onChange={(e) => onSlotUrlChange(activeKey, e.target.value)}
          />
        </>
      )}
    </div>
  )
}
