export default function ConfirmModal({ title, message, onConfirm, onCancel }) {
  return (
    <div className="modal-backdrop" onClick={onCancel}>
      <div className="confirm-panel" onClick={(e) => e.stopPropagation()}>
        <h3>{title}</h3>
        <p>{message}</p>
        <div className="modal-actions">
          <button className="btn-secondary" onClick={onCancel} type="button">
            취소
          </button>
          <button className="btn-danger" onClick={onConfirm} type="button">
            삭제
          </button>
        </div>
      </div>
    </div>
  )
}
