import { useState, useEffect } from 'react'
import StyleAndSlotsFields from './StyleAndSlotsFields'

const emptySlots = () => ({
  girl: { url: '', label: 'girl' },
  boy: { url: '', label: 'boy' },
  none: { url: '', label: '빈프롬' },
})

export default function TagEditorModal({ initial, existingStyles, onSave, onClose }) {
  const [name, setName] = useState(initial?.name || '')
  const [styles, setStyles] = useState(initial?.styles || [])
  const [styleInput, setStyleInput] = useState('')
  const [memo, setMemo] = useState(initial?.memo || '')
  const [slots, setSlots] = useState(initial?.slots || emptySlots())
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  const addStyle = () => {
    const v = styleInput.trim()
    if (v && !styles.includes(v)) {
      setStyles([...styles, v])
    }
    setStyleInput('')
  }

  const removeStyle = (s) => setStyles(styles.filter((x) => x !== s))

  const updateSlotUrl = (key, url) => {
    setSlots((prev) => ({ ...prev, [key]: { ...prev[key], url } }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!name.trim() || saving) return
    setSaving(true)
    try {
      await onSave({ name: name.trim(), styles, memo: memo.trim(), slots })
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-panel" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{initial ? '작가 태그 수정' : '새 작가 태그'}</h2>
          <button className="modal-close" onClick={onClose} aria-label="닫기" type="button">
            ×
          </button>
        </div>

        <form className="modal-form" onSubmit={handleSubmit}>
          <section className="form-section">
            <label className="form-label">작가 태그</label>
            <input
              className="text-input mono"
              type="text"
              placeholder="예: artist:something 또는 태그명"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </section>

          <StyleAndSlotsFields
            styles={styles}
            styleInput={styleInput}
            onStyleInputChange={setStyleInput}
            onAddStyle={addStyle}
            onRemoveStyle={removeStyle}
            onPickSuggestion={(s) => {
              setStyles([...styles, s])
              setStyleInput('')
            }}
            existingStyles={existingStyles}
            slots={slots}
            onSlotUrlChange={updateSlotUrl}
          />

          <section className="form-section">
            <label className="form-label">메모 (선택)</label>
            <textarea
              className="text-input textarea"
              placeholder="특징이나 조합 팁 등을 자유롭게 적어두세요"
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              rows={2}
            />
          </section>

          <div className="modal-actions">
            <button type="button" className="btn-secondary" onClick={onClose} disabled={saving}>
              취소
            </button>
            <button type="submit" className="btn-primary" disabled={saving}>
              {saving ? '저장 중...' : '저장'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
