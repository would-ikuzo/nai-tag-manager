export default function LoginScreen({ onLogin, deniedEmail, firebaseConfigured }) {
  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="login-mark">画</div>
        <h1 className="login-title">작가 태그 서가</h1>
        <p className="login-sub">본인 계정으로만 접근 가능한 개인 색인입니다.</p>

        {!firebaseConfigured && (
          <div className="login-warning">
            Firebase 설정값이 비어 있습니다. <code>.env</code> 파일에 설정값을 입력해주세요.
          </div>
        )}

        {deniedEmail && (
          <div className="login-warning">
            <strong>{deniedEmail}</strong> 계정은 접근이 허용되지 않았습니다.
          </div>
        )}

        <button className="google-btn" onClick={onLogin} disabled={!firebaseConfigured}>
          <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
            <path
              fill="#4285F4"
              d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.9c1.7-1.57 2.7-3.88 2.7-6.62z"
            />
            <path
              fill="#34A853"
              d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.9-2.26c-.8.54-1.84.86-3.06.86-2.35 0-4.34-1.59-5.05-3.72H.9v2.33A9 9 0 0 0 9 18z"
            />
            <path
              fill="#FBBC05"
              d="M3.95 10.7A5.4 5.4 0 0 1 3.67 9c0-.59.1-1.17.28-1.7V4.97H.9A9 9 0 0 0 0 9c0 1.45.35 2.83.9 4.03l3.05-2.33z"
            />
            <path
              fill="#EA4335"
              d="M9 3.58c1.32 0 2.51.46 3.44 1.35l2.58-2.58C13.46.89 11.43 0 9 0A9 9 0 0 0 .9 4.97l3.05 2.33C4.66 5.17 6.65 3.58 9 3.58z"
            />
          </svg>
          Google 계정으로 로그인
        </button>
      </div>
    </div>
  )
}
