# NAI 작가 태그 서가

NovelAI 작가 태그를 검색·분류·복사할 수 있는 **1인용** 웹앱입니다. Google 로그인(본인
계정만 허용) + Firebase Firestore로 멀티 디바이스 동기화를 지원합니다.

이 저장소는 **포크해서 각자 본인의 Firebase/Supabase 계정에 연결해 쓰는 것**을 전제로
만들어졌습니다. 별도의 회원가입 시스템이 없고, 딱 한 사람(또는 본인이 지정한 소수의
이메일)만 로그인해서 쓸 수 있는 개인용 도구예요.

> ⚠️ 라이선스 안내: 이 프로젝트는 개인적으로 자유롭게 쓰고 수정·재배포할 수 있지만,
> **상업적 이용**이나 **여러 명이 가입해서 쓰는 멀티유저 서비스로 공개 운영**하려면
> 원저작자의 사전 허락이 필요합니다. 자세한 내용은 [LICENSE.md](./LICENSE.md)를
> 확인해주세요.

---

## 1. 이 프로젝트가 하는 일

- 작가 태그를 등록/검색/즐겨찾기/원클릭 복사
- 화풍 등 자유 분류 태그로 다중 필터링
- 태그마다 `girl` / `boy` / `빈프롬(None)` 3개의 예시 이미지 슬롯 (스와이프 전환)
- 정렬: 최신순 / 오래된순 / 알파벳순 / 직접 드래그 정렬
- 작가 태그 조합("그깍") 별도 관리 — 프롬프트, Steps, Prompt Guidance, Sampler 등 저장
- Google 로그인 기반 접근 제한 (지정한 이메일만 접근 가능)
- Firestore 실시간 동기화로 여러 기기에서 같은 데이터 공유

---

## 2. 준비물

- Node.js 18 이상
- Firebase 프로젝트 (무료 Spark 플랜으로 충분)
- (선택) Supabase 프로젝트 — 이미지 드래그앤드롭 업로드 기능을 쓰고 싶다면 필요합니다.
  설정하지 않아도 이미지 URL 직접 입력으로는 계속 사용 가능합니다.

---

## 3. Firebase 콘솔 설정

### 3-1. 프로젝트 생성 & 웹 앱 등록
1. [Firebase 콘솔](https://console.firebase.google.com/)에서 새 프로젝트 생성
2. 프로젝트 설정 → 내 앱 → `</>` (웹 앱 추가) → 앱 등록
3. 표시되는 `firebaseConfig` 값들을 복사해둡니다 (`apiKey`, `authDomain`, `projectId` 등)

### 3-2. Authentication 활성화 (Google 로그인)
1. **Authentication** → **시작하기** → **Sign-in method** 탭
2. **Google** 선택 → 사용 설정 ON → 저장

### 3-3. Firestore 데이터베이스 생성
1. **Firestore Database** → **데이터베이스 만들기**
2. 리전은 가까운 곳으로 선택 (한국이면 `asia-northeast3` 추천)
3. 테스트 모드로 시작해도 되지만, 아래 5번 항목의 보안 규칙을 반드시 적용하세요.

---

## 4. (선택) Supabase 설정 — 이미지 업로드 기능

1. [supabase.com](https://supabase.com)에서 프로젝트 생성
2. **Storage** → **New bucket** → 이름 입력(예: `nai-images`) → **Public bucket** 체크 → 생성
3. **Project Settings → API**에서 **Project URL**, **anon public** 키 복사

이 단계를 건너뛰어도 앱은 정상 동작하며, 이미지는 URL을 직접 입력해서 쓰면 됩니다.

---

## 5. 프로젝트 설정

### 5-1. 패키지 설치
```bash
npm install
```

### 5-2. 환경변수 설정
```bash
cp .env.example .env
```

`.env` 파일을 열어 Firebase/Supabase 콘솔에서 복사한 값을 채워주세요.

```env
VITE_FIREBASE_API_KEY=AIza...
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project
VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
VITE_FIREBASE_APP_ID=1:123456789:web:abcdef

# 본인 구글 계정 이메일 (이 이메일로만 로그인 허용)
VITE_ALLOWED_EMAILS=you@gmail.com

# (선택) Supabase — 안 쓸 거면 비워둬도 됩니다
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
VITE_SUPABASE_BUCKET=nai-images
```

> `VITE_ALLOWED_EMAILS`는 클라이언트 단(화면)에서의 1차 방어입니다. 진짜 보안은
> **Firestore 보안 규칙**(6번 항목)이 담당하므로, 두 곳 모두 같은 이메일로 맞춰주세요.

### 5-3. Firestore 보안 규칙에 본인 이메일 반영
`firestore.rules` 파일을 열어 `YOUR_EMAIL@gmail.com` 부분을 전부 본인 이메일로
바꿔주세요.

```js
allow read, write: if request.auth != null
  && request.auth.token.email == "you@gmail.com";
```

여러 계정을 허용하려면:
```js
allow read, write: if request.auth != null
  && request.auth.token.email in ["you@gmail.com", "second@gmail.com"];
```

---

## 6. 로컬 실행

```bash
npm run dev
```

터미널에 뜨는 주소(기본 `http://localhost:5173`)로 접속하면 로그인 화면이 나옵니다.

---

## 7. Firebase Hosting에 배포하기

### 7-1. Firebase CLI 설치 & 로그인 (최초 1회)
```bash
npm install -g firebase-tools
firebase login
```

### 7-2. 프로젝트 연결 (최초 1회)
```bash
firebase use --add
```
목록에서 본인 프로젝트 선택 → 별칭은 `default` 정도로 입력

### 7-3. Firestore 보안 규칙 배포
```bash
firebase deploy --only firestore:rules
```

### 7-4. 빌드 후 호스팅 배포
```bash
npm run build
firebase deploy --only hosting
```

배포가 끝나면 `https://your-project.web.app` 형태의 주소가 출력됩니다.

> 기본 배포 주소 대신 본인만의 이름을 쓰고 싶다면 `firebase hosting:sites:create 원하는이름`
> 으로 사이트를 추가로 만든 뒤, `firebase.json`의 `"hosting"` 안에
> `"site": "원하는이름"` 을 추가하고 다시 배포하면 됩니다.

> Google 로그인이 배포 도메인에서 동작하려면, **Authentication → Settings →
> 승인된 도메인**에 배포된 주소(`your-project.web.app` 등)가 등록되어 있어야 합니다.
> 보통 자동으로 추가되지만, 사이트 이름을 바꿨다면 직접 추가해야 할 수 있습니다.

---

## 8. 기능 요약

| 기능 | 설명 |
|---|---|
| Google 로그인 | 지정한 이메일만 접근 허용 (클라이언트 화이트리스트 + Firestore 규칙 이중 체크) |
| 실시간 동기화 | Firestore `onSnapshot`으로 여러 기기 간 즉시 반영 |
| 검색 | 태그명 실시간 검색 |
| 즐겨찾기 | ★ 토글, 목록 상단 고정 정렬 |
| 원클릭 복사 | 태그 카드의 복사 아이콘 클릭 시 클립보드 복사 |
| 정렬 | 최신순 / 오래된순 / 알파벳순 / 기타(드래그로 직접 순서 변경, Firestore에 저장됨) |
| 화풍/분류 태그 | 작가 태그당 다중 분류 태그 부여, 상단 칩 클릭으로 다중 필터 (AND 조건) |
| 화풍 태그 관리 | 화풍/분류 태그를 별도 화면에서 등록·이름변경·삭제 (`styleTags` 컬렉션으로 독립 관리) |
| 일괄 작업 | 카드 다중 선택 후 화풍 태그 일괄 추가, 즐겨찾기 일괄 등록/해제, 일괄 삭제 |
| 예시 이미지 3슬롯 | `girl` / `boy` / `빈프롬(None)` 슬롯별 이미지, 스와이프/좌우 화살표로 전환 |
| 전역 슬롯 필터 | 상단 `전체/girl/boy/빈프롬` 토글 선택 시 모든 카드가 해당 슬롯 이미지로 고정 표시 |
| 이미지 업로드 | Supabase 설정 시 드래그앤드롭/클릭으로 이미지 파일 업로드 가능. 미설정 시 URL 직접 입력만 가능 |
| 그깍(조합) 탭 | 작가 태그 조합 관리 — 메인/부정 프롬프트, Steps·Prompt Guidance·Sampler 설정, Advanced(Rescale·Noise Schedule), 화풍/예시 이미지/즐겨찾기까지 작가 태그와 동일하게 지원 |

---

## 9. 폴더 구조

```
src/
  components/     화면 구성 요소 (카드, 모달, 필터바, 캐러셀, 일괄작업바 등)
  hooks/          useAuth(로그인), useCollection(공통 CRUD), useStyleTags(화풍 태그 관리)
  lib/            firebase.js, supabase.js, uploadImage.js
  styles/         디자인 토큰 + 전체 스타일시트
firestore.rules    Firestore 보안 규칙 (본인 이메일로 수정 필요)
firebase.json      Hosting/Firestore 배포 설정
LICENSE.md         라이선스 (사용 조건)
```

---

## 10. 자주 발생할 수 있는 문제

- **로그인 버튼이 비활성화되어 있어요** → `.env`의 Firebase 설정값이 비어있는지 확인하세요.
- **로그인은 되는데 "접근이 허용되지 않았습니다" 메시지가 떠요** → `.env`의
  `VITE_ALLOWED_EMAILS`와 로그인한 구글 계정 이메일이 일치하는지 확인하세요.
- **저장 버튼을 눌러도 반응이 없어요 (Firestore 권한 에러)** → `firestore.rules`에
  본인 이메일을 반영했는지, 그리고 그 규칙을 실제로 **게시(Publish)** 했는지
  (Firebase 콘솔 또는 `firebase deploy --only firestore:rules`) 확인하세요.
- **이미지가 안 떠요** → 입력한 이미지 URL이 실제로 브라우저에서 직접 열리는 이미지
  주소인지 확인하세요. (리다이렉트되는 공유 링크는 안 될 수 있습니다.)
- **로그인 시 `auth/unauthorized-domain` 에러** → Firebase Authentication → Settings →
  승인된 도메인에 배포 주소를 추가하세요.

---

## 11. 기여 / 문의

버그 제보나 개선 제안은 이 저장소의 Issue로 남겨주세요. 상업적 이용이나 멀티유저
서비스 운영을 원하시면 Issue를 통해 먼저 연락해주세요.
